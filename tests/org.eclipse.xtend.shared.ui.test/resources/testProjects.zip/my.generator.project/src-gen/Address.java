public class Address {

	private String street;

	public void setStreet(String street) {
		this.street = street;
	}

	public String getStreet() {
		return street;
	}

	private String zip;

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getZip() {
		return zip;
	}

	private String city;

	public void setCity(String city) {
		this.city = city;
	}

	public String getCity() {
		return city;
	}

}
